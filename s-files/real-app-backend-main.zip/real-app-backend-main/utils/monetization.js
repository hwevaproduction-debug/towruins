const MONETIZATION_MODE = process.env.MONETIZATION_MODE || "LANDLORD_PAID";

const isLandlordPaid = (user) => {
  if (!user) return false;
  if (user.landlordPlan === "pro") return true;
  if (user.isLandlordPaid === true) return true;
  if (user.subscriptionStatus === "active") return true;
  if (user.landlordPaidUntil && new Date(user.landlordPaidUntil) > new Date()) {
    return true;
  }
  return false;
};

module.exports = {
  MONETIZATION_MODE,
  isLandlordPaid,
};
