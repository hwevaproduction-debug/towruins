// React Imports
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
// Material UI Imports
import {
  Box,
  Avatar,
  IconButton,
  MenuItem,
  Menu,
  styled,
  MenuProps,
  Tooltip,
} from "@mui/material";
// Component Imports
import { Heading } from "../Heading";
import SearchBar from "../SearchBar";
import AppButton from "../ui/AppButton";
import AppContainer from "../ui/AppContainer";
// Hooks Imports
import useTypedSelector from "../../hooks/useTypedSelector";
// Redux Imports
import {
  selectedUserAvatar,
  selectedUserName,
  selectedUserRole,
  setUser,
} from "../../redux/auth/authSlice";
// Icons Imports
import { ImProfile } from "react-icons/im";
import { IoLogOutOutline } from "react-icons/io5";
import {
  selectedSearchText,
  setSearchText,
} from "../../redux/global/globalSlice";

const menuStyle = {
  cursor: "pointer",
  "&:hover": {
    textDecoration: "underline",
  },
};

const StyledMenu = styled((props: MenuProps) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(() => ({
  "& .MuiPaper-root": {
    borderRadius: 12,
    width: "100%",
    maxWidth: 260,
    background: "#fff",
    color: "#334155",
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "10px 5px",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
      },
    },
  },
}));

const Header = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const avatar = useTypedSelector(selectedUserAvatar);
  const userName = useTypedSelector(selectedUserName);
  const userRole = useTypedSelector(selectedUserRole);
  const searchText = useTypedSelector(selectedSearchText);

  const [anchorEl, setAnchorEl] = useState<Element | null>(null);
  const [searchTerm, setSearchTerm] = useState("");

  const handleSearch = (event: any) => {
    let value = event.target.value.toLowerCase();
    dispatch(setSearchText(value));
    setSearchTerm(value);
  };

  const handleSubmit = (e: any) => {
    e.preventDefault();
    const urlParams = new URLSearchParams(window.location.search);
    urlParams.set("searchTerm", searchTerm);
    const searchQuery = urlParams.toString();
    navigate(`/search?${searchQuery}`);
  };

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const searchTextFromUrl = urlParams.get("searchTerm");
    if (searchTextFromUrl) {
      dispatch(setSearchText(searchTextFromUrl));
      setSearchTerm(searchTextFromUrl);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [window.location.search]);

  return (
    <header>
      <Box
        sx={{
          position: "sticky",
          top: 0,
          zIndex: 1100,
          background: "rgba(243, 246, 241, 0.9)",
          backdropFilter: "blur(8px)",
          borderBottom: "1px solid rgba(226, 232, 240, 0.7)",
        }}
      >
        <AppContainer>
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              minHeight: "72px",
              py: { xs: 1, md: 1.5 },
              gap: 2,
              flexWrap: { xs: "wrap", md: "nowrap" },
            }}
          >
            <Box
              onClick={() => navigate("/")}
              sx={{ display: "flex", cursor: "pointer", alignItems: "center" }}
            >
              <Heading sx={{ color: "#2B6A50" }}>Real</Heading>
              <Heading sx={{ color: "#1F2937" }}>Estate</Heading>
            </Box>

            <Box sx={{ flex: 1, minWidth: { xs: "100%", md: 320 } }}>
              <form onSubmit={handleSubmit}>
                <SearchBar
                  placeholder="Search locations, listings..."
                  searchText={searchText}
                  handleSearch={handleSearch}
                  value={searchTerm}
                  onChange={handleSearch}
                />
              </form>
            </Box>

            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: { xs: 1.5, md: 2 },
                flexWrap: "wrap",
                justifyContent: { xs: "center", md: "flex-end" },
              }}
            >
              <Box sx={menuStyle} onClick={() => navigate("/")}>
                Home
              </Box>
              <Box sx={menuStyle} onClick={() => navigate("/about")}>
                About
              </Box>
              <Box sx={menuStyle} onClick={() => navigate("/search")}>
                Properties
              </Box>

              {avatar ? (
                <>
                  {userRole === "landlord" && (
                    <AppButton
                      variant="contained"
                      onClick={() => navigate("/create-listing")}
                    >
                      Create Listing
                    </AppButton>
                  )}
                  <Box sx={{ cursor: "pointer" }}>
                    <IconButton
                      onClick={(e) => setAnchorEl(e.currentTarget)}
                      color="inherit"
                    >
                      <Avatar alt="User Avatar" src={avatar} />
                    </IconButton>
                    <StyledMenu
                      onClick={() => setAnchorEl(null)}
                      anchorEl={anchorEl}
                      open={Boolean(anchorEl)}
                    >
                      <MenuItem
                        sx={{
                          "&:hover": {
                            background: "unset",
                            cursor: "unset",
                          },
                        }}
                      >
                        <Box
                          sx={{ display: "flex", alignItems: "center", gap: 1 }}
                        >
                          <img
                            height={30}
                            width={30}
                            src={avatar}
                            alt="user"
                            style={{ borderRadius: "50%" }}
                          />
                          <Box>{userName}</Box>
                        </Box>
                      </MenuItem>
                      <MenuItem
                        sx={{
                          "&:hover": {
                            background: "unset",
                          },
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            width: "100%",
                            gap: "3px",
                            marginTop: "5px",
                          }}
                        >
                          <Tooltip title="See Profile" placement="bottom">
                            <Box
                              sx={{
                                background: "#eff1f7",
                                borderTopLeftRadius: "12px",
                                borderBottomLeftRadius: "12px",
                                width: "100%",
                                padding: "6px 10px",
                                display: "flex",
                                alignItems: "center",
                                gap: 1,
                              }}
                              onClick={() => {
                                navigate("/profile");
                              }}
                            >
                              <ImProfile />
                              Profile
                            </Box>
                          </Tooltip>
                          <Tooltip title="Logout Profile" placement="bottom">
                            <Box
                              sx={{
                                background: "#eff1f7",
                                borderTopRightRadius: "12px",
                                borderBottomRightRadius: "12px",
                                width: "100%",
                                padding: "6px 10px",
                                display: "flex",
                                alignItems: "center",
                                gap: 1,
                              }}
                              onClick={() => {
                                dispatch(setUser(null));
                                localStorage.removeItem("user");
                                setAnchorEl(null);
                                navigate("/");
                              }}
                            >
                              <IoLogOutOutline /> Logout
                            </Box>
                          </Tooltip>
                        </Box>
                      </MenuItem>
                    </StyledMenu>
                  </Box>
                </>
              ) : (
                <>
                  <Box sx={menuStyle} onClick={() => navigate("/login")}>
                    Log in
                  </Box>
                  <AppButton onClick={() => navigate("/signup")}>
                    Sign up
                  </AppButton>
                </>
              )}
            </Box>
          </Box>
        </AppContainer>
      </Box>
    </header>
  );
};

export default Header;
