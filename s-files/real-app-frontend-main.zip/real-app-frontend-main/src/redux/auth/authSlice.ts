// Redux Toolkit Imports
import { createSlice } from "@reduxjs/toolkit";
// Custom Imports
import { RootState } from "../store";
import { MONETIZATION_MODE, isLandlordPaidUser } from "../../config/monetization";

const getInitialUser = () => {
  const localStorageItem = localStorage.getItem("user");
  if (localStorageItem) {
    return JSON.parse(localStorageItem);
  } else {
    return null;
  }
};

const authSlice = createSlice({
  name: "auth",
  initialState: {
    user: getInitialUser(),
  },
  reducers: {
    setUser(state, action) {
      state.user = action.payload;
    },
  },
});

export const { setUser } = authSlice.actions;
export default authSlice.reducer;

export const selectedUserId = (state: RootState) =>
  state.auth?.user?.data?.user?._id;
export const selectedUserName = (state: RootState) =>
  state.auth?.user?.data?.user?.username;
export const selectedUserEmail = (state: RootState) =>
  state.auth?.user?.data?.user?.email;
export const selectedUserAvatar = (state: RootState) =>
  state.auth?.user?.data?.user?.avatar;

export const selectedUserRole = (state: RootState) =>
  state.auth?.user?.data?.user?.role;

export const selectedUserPremiumStatus = (state: RootState) =>
  state.auth?.user?.data?.user?.premiumStatus;

export const selectedUserLandlordPlan = (state: RootState) =>
  state.auth?.user?.data?.user?.landlordPlan;

export const selectedUserIsLandlordPaid = (state: RootState) =>
  isLandlordPaidUser(state.auth?.user?.data?.user);

export const selectedCanPublishListing = (state: RootState) => {
  const user = state.auth?.user?.data?.user;
  const role = user?.role;

  if (role !== "landlord") return false;
  if (MONETIZATION_MODE !== "LANDLORD_PAID") return true;

  return isLandlordPaidUser(user);
};
