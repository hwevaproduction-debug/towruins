export type MonetizationMode = "LANDLORD_PAID" | "TENANT_PAID";

const rawMode =
  process.env.REACT_APP_MONETIZATION_MODE ||
  process.env.MONETIZATION_MODE ||
  "LANDLORD_PAID";

export const MONETIZATION_MODE: MonetizationMode =
  rawMode === "TENANT_PAID" ? "TENANT_PAID" : "LANDLORD_PAID";

export const isLandlordPaidUser = (user: any): boolean => {
  if (!user) return false;

  if (user?.landlordPlan === "pro") return true;
  if (user?.subscriptionStatus === "active") return true;
  if (user?.isLandlordPaid === true) return true;
  return false;
};
